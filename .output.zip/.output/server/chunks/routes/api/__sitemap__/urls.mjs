import { c as defineSitemapEventHandler } from '../../../_/nitro.mjs';
import 'lru-cache';
import '@unocss/core';
import '@unocss/preset-wind3';
import 'devalue';
import 'consola';
import 'unhead';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'node:fs';
import 'node:url';
import 'unhead/server';
import 'unhead/plugins';
import 'unhead/utils';
import 'vue-bundle-renderer/runtime';
import 'vue/server-renderer';
import '@iconify/utils';
import 'node:crypto';
import 'ipx';
import 'node:path';

const urls = defineSitemapEventHandler(() => {
  const staticPages = [
    { loc: "/", changefreq: "weekly", priority: 1 },
    { loc: "/about", changefreq: "monthly", priority: 0.8 },
    { loc: "/services", changefreq: "weekly", priority: 0.9 },
    { loc: "/contact", changefreq: "monthly", priority: 0.7 }
  ];
  return staticPages;
});

export { urls as default };
//# sourceMappingURL=urls.mjs.map
